sap.ui.define([
	"synczec/rec_service/test/unit/controller/rec_service1.controller"
], function () {
	"use strict";
});
