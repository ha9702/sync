sap.ui.define([], function () {
    "use strict";

    return {
        quoteText: function (sText) {
            return "\"" + sText + "\"";
        }
    };
});