/* global QUnit */

sap.ui.require(["sync/zec/sales1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
