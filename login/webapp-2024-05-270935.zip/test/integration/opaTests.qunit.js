/* global QUnit */

sap.ui.require(["sync/zec/login/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
