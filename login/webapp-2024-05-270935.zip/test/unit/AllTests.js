sap.ui.define([
	"synczec/login/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
