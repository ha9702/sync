sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
], 
    /**
     * provide app-view type models (as in the first "V" in MVVC)
     * 
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
     * @param {typeof sap.ui.Device} Device
     * 
     * @returns {Function} createDeviceModel() for providing runtime info for the device the UI5 app is running on
     */
    function (JSONModel, Device) {
        "use strict";

        return {
            createDeviceModel: function () {
                var oModel = new JSONModel(Device);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },
            createCartModel: function () {
                var oCartModel = new JSONModel({
                    cartItems: [],
                    selectedProduct: {},
                    editMode: false,
                    totalPrice: 0,
                    SelectedPayment: "Card",
                    Submonth: 0,
                    pillNetpr: 0,
                    Kunnr: "",
                    Flag: "",
                    Before: ""
                });
                oCartModel.setDefaultBindingMode("TwoWay");
                return oCartModel;
            }
    };
});