sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
], function (Controller, MessageToast) {
    "use strict";

    return Controller.extend("sync.zec.recservice.controller.rec_result", {
        onInit: function () {
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("rec_result").attachPatternMatched(this._onObjectMatched, this);
        },

        _onObjectMatched: function () {
            var oModel = this.getOwnerComponent().getModel("selectionModel"); // Component에 있는 모델 사용할 때
            this.getView().setModel(oModel, "selectionModel");

            this._setResultBasedOnSelection();
        },

        _setResultBasedOnSelection: function() {
            var oModel = this.getView().getModel("selectionModel");
            var aSelectedItems = oModel.getProperty("/selectedItems");
            var sUserName = oModel.getProperty("/userName");
            var sGender = oModel.getProperty("/selectedGender");
            var sAgeGroup = oModel.getProperty("/selectedAgeGroup");
            var sMedicationName = oModel.getProperty("/medicationName");

            // 결과를 저장할 모델 생성
            var oResultModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oResultModel, "resultModel");

            // 선택 항목에 따른 결과 설정
            var aResults = [];
            var sCustomMessage = "";  // ##형 이라고 뜰 맞춤형 결과 메시지

            if (aSelectedItems.includes("간 건강")) {
                aResults.push({
                    name: "밀크씨슬",
                    description: "밀크씨슬은 간 건강에 도움을 줍니다.",
                    imageUrl: "../images/밀크씨슬.png"
                    
                });
                aResults.push({
                    name: "아르기닌",
                    description: "아르기닌은 간 건강과 관절/근육 강화에 도움을 줍니다.",
                    imageUrl: "../images/아르기닌.png"
                });
                sCustomMessage = "간이 피로해 형";
            }
            if (aSelectedItems.includes("콜레스테롤")) {
                aResults.push({
                    name: "코큐텐",
                    description: "코큐텐은 콜레스테롤 관리에 도움을 줍니다.",
                    imageUrl: "../images/코큐텐.png"
                });
            }
            if (aSelectedItems.includes("혈압 관리")) {
                aResults.push({
                    name: "비타민B플러스",
                    description: "비타민B는 혈압관리와 뇌건강에 도움을 줍니다.",
                    imageUrl: "../images/비타민B플러스.png"
                });
                aResults.push({
                    name: "오메가3",
                    description: "오메가3는 혈압관리와 눈건강에 도움을 줍니다.",
                    imageUrl: "../images/오메가3.png"
                });
                sCustomMessage = "협압상승!! 형";
            }
            if (aSelectedItems.includes("혈당 관리")) {
                aResults.push({
                    name: "마그네슘",
                    description: "마그네슘은 혈당관리에 도움을 줍니다.",
                    imageUrl: "../images/마그네슘.png"
                });
                sCustomMessage = "혈당이 위험해 형";
            }
            if (aSelectedItems.includes("뇌 건강")) {
                aResults.push({
                    name: "비타민B플러스",
                    description: "비타민B는 혈압관리와 뇌건강에 도움을 줍니다.",
                    imageUrl: "../images/비타민B플러스.png"
                });
                aResults.push({
                    name: "징코민",
                    description: "징코민은 뇌건강에 도움을 줍니다.",
                    imageUrl: "../images/징코민.png"
                });
            }
            if (aSelectedItems.includes("눈 건강")) {
                aResults.push({
                    name: "오메가3",
                    description: "오메가3는 혈압관리와 눈건강에 도움을 줍니다.",
                    imageUrl: "../images/오메가3.png"
                });
                aResults.push({
                    name: "루테인",
                    description: "루테인은 눈건강에 도움을 줍니다.",
                    imageUrl: "../images/루테인.png"
                });
                sCustomMessage = "하루종일 모니터만 바라봐 형";
            }
            if (aSelectedItems.includes("뼈 건강")) {
                aResults.push({
                    name: "마그네슘",
                    description: "마그네슘은 혈압관리와 뼈건강에 도움을 줍니다.",
                    imageUrl: "../images/마그네슘.png"
                });
                sCustomMessage = "비실이 형";
            }
            if (aSelectedItems.includes("위장 건강")) {
                aResults.push({
                    name: "프로바이오틱스",
                    description: "프로바이오틱스는 장 건강에 도움을 줍니다.",
                    imageUrl: "../images/프로바이오틱스.png"
                });
                sCustomMessage = "바쁘다바빠 소화불량 사회인 형";
            }
            if (aSelectedItems.includes("관절/근육")) {
                aResults.push({
                    name: "아르기닌",
                    description: "아르기닌은 간 건강과 관절/근육 강화에 도움을 줍니다.",
                    imageUrl: "../images/아르기닌.png"
                })
                aResults.push({
                    name: "콘드로이진",
                    description: "콘드로이진은 관절/근육 강화에 도움을 줍니다.",
                    imageUrl: "../images/콘드로이진.png"
                })
                sCustomMessage = "이젠 관리할 나이 형";
            }
            if (aSelectedItems.includes("면역력")) {
                aResults.push({
                    name: "비타민B플러스",
                    description: "비타민B는 면역력 강화에 도움을 줍니다.",
                    imageUrl: "../images/비타민B플러스.png"
                });
                aResults.push({
                    name: "코큐텐",
                    description: "코큐텐은 면역력 강화에 도움을 줍니다.",
                    imageUrl: "../images/코큐텐.png"
                });
                sCustomMessage = "나를 지켜야 하는 형";
            }
            if (aSelectedItems.includes("스트레스")) {
                aResults.push({
                    name: "비타민B플러스",
                    description: "비타민B는 스트레스 관리에 도움을 줍니다.",
                    imageUrl: "../images/비타민B플러스.png"
                });
                aResults.push({
                    name: "L-테아닌",
                    description: "L-테아닌는 스트레스 관리에 도움을 줍니다.",
                    imageUrl: "../images/L-테아닌.png"
                });
                sCustomMessage = "스트레스 만땅 현대인 형";
            }
            if (aSelectedItems.includes("모발")) {
                aResults.push({
                    name: "비오틴",
                    description: "비오틴은 모발 건강에 도움을 줍니다.",
                    imageUrl: "../images/비오틴.png"
                });
                sCustomMessage = "모발이..필요해 형";
            }
            if (aSelectedItems.includes("수면")) {
                aResults.push({
                    name: "멜라토닌",
                    description: "멜라토닌은 수면에 도움을 줍니다.",
                    imageUrl: "../images/멜라토닌.png"
                });
                sCustomMessage = "잠이 필요해ㅠㅅㅠ 형";
            }
            if (aSelectedItems.includes("피부")) {
                aResults.push({
                    name: "글루타치온",
                    description: "글루타치온은 피부 관리에 도움을 줍니다.",
                    imageUrl: "../images/글루타치온.png"
                });
                sCustomMessage = "피부미인이 될거야 형";
            }
            if (aSelectedItems.includes("체지방관리")) {
                aResults.push({
                    name: "가르시니아",
                    description: "가르시니아는 체지방 관리에 도움을 줍니다.",
                    imageUrl: "../images/가르시니아.png"
                });
                sCustomMessage = "올해는 다이어트할거야 형";
            }

            var bAlreadyTaking = aResults.some(function(result) {
                return result.name === sMedicationName;
            });

            if (bAlreadyTaking) {
                oResultModel.setProperty("/alreadyTakingMessage", ` * 현재 복용중인 ${sMedicationName}을(를) 고려해서 추천된 조합이니 안심하세요 :) `);
            } else {
                oResultModel.setProperty("/alreadyTakingMessage", "");
            }

            oResultModel.setProperty("/results", aResults);
            oResultModel.setProperty("/userName", sUserName);
            oResultModel.setProperty("/customMessage", sCustomMessage);
            oResultModel.setProperty("/userDetails", `[ ${sUserName}: ${sAgeGroup} ${sGender} ]`); // 사용자 세부정보 설정
        },

        onPurchase: function() {
            MessageToast.show("맞춤 영양제 구매하러 가기");
        },

        onConsult: function() {
            MessageToast.show("전문가 상담 예약하러 가기");
        }
    });
});
