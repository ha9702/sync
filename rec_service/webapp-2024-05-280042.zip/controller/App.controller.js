sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sync.zec.recservice.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  