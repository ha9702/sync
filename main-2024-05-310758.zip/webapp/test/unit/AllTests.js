sap.ui.define([
	"synczec/main/test/unit/controller/Master.controller"
], function () {
	"use strict";
});
